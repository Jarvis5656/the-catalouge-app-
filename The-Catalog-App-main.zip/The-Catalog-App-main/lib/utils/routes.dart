class MyRoutes {
  static String loginRoute = "/login";
  static String homeRoute = "/home";
  static String homeDetailsRoute = "/detail";
  static String cartRoute = "/cart";
}
