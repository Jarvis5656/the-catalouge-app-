# catalouge
To rum the app follow Steps 1 - Download the files from github 2 - Open project in Android Studio or Visual studio code 3 - From Android Studio: Click Packages get in the action ribbon at the top of pubspec. yaml . From VS Code: Click Get Packages located in right side of the action ribbon at the top of pubspec. yaml. OR 4 - Open terminal and run flutter pub get 5 - The App is ready to Run!
api used - https://api.jsonbin.io/b/604dbddb683e7e079c4eefd3
You can also run this on your ios device , android device , windows os,mac os,ubutnu.
As this app was desiged for mobile their might be some UI issues ruuning it on any other machine which you can fix easily by using isWeb or isDesktop.
